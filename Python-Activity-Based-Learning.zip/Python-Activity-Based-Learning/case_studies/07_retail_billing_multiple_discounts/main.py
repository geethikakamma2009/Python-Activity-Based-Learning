# Case Study 7: Retail Billing with Multiple Discount Rules
items = [
    {"name": "Headphones", "category": "electronics", "price": 1200, "quantity": 1},
    {"name": "Rice Bag", "category": "grocery", "price": 800, "quantity": 2},
    {"name": "USB Cable", "category": "electronics", "price": 250, "quantity": 2},
]
tax_rates = {"electronics": 0.18, "grocery": 0.05}
subtotal = sum(item["price"] * item["quantity"] for item in items)
discount = min(subtotal * 0.10, 300) if subtotal >= 2000 else 0
print("RETAIL INVOICE")
print("Item                 Qty   Amount")
for item in items:
    amount = item["price"] * item["quantity"]
    print(f"{item['name']:<20} {item['quantity']:>3}   ₹{amount:.2f}")
print(f"Subtotal: ₹{subtotal:.2f}")
print(f"Discount: ₹{discount:.2f}")
# Allocate the discount proportionally before applying each category's tax.
tax_total = 0
for item in items:
    amount = item["price"] * item["quantity"]
    allocated_discount = discount * amount / subtotal if subtotal else 0
    taxable_amount = amount - allocated_discount
    tax_total += taxable_amount * tax_rates[item["category"]]
print(f"Tax: ₹{tax_total:.2f}")
print(f"GRAND TOTAL: ₹{subtotal - discount + tax_total:.2f}")
