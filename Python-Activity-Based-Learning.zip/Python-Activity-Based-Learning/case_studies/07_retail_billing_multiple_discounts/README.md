# Case Study 7: Retail Billing with Multiple Discount Rules

## 1. Problem Statement
Create an itemized invoice for products with quantities, category-specific taxes, threshold discounts, and a maximum concession limit.

## 2. Objectives
- Calculate line totals and category taxes.
- Apply a discount based on the pre-tax subtotal.
- Limit the discount to the maximum allowed amount and print an invoice.

## 3. Assumptions
- Electronics tax is 18%; groceries tax is 5%.
- Discount is 10% if pre-tax subtotal is at least ₹2,000.
- Maximum discount is ₹300.
- Discount is applied before tax, distributed proportionally across the basket for this exercise.

## 4. Algorithm
1. Start the program.
2. Store the sample records and policy constants in variables, lists, or dictionaries.
3. Validate inputs where applicable.
4. Use arithmetic operators and conditional statements to calculate the required values.
5. Use loops to process all records and lists to store intermediate results.
6. Apply ranking, comparison, or summary logic as required.
7. Display the final results and stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read sample records and rules]
    B --> C[Validate inputs]
    C --> D[Calculate values using variables and operators]
    D --> E{Eligibility / threshold condition?}
    E -->|Yes| F[Record result / apply rule]
    E -->|No| G[Record alternative result]
    F --> H[Display summary and test results]
    G --> H
    H --> I([End])
```

## 6. Pseudocode
```text
START
    Set the sample data and policy constants
    FOR each record
        Validate values
        Calculate the required totals and conditions
        Display the record result
        Store eligible/summary values when required
    END FOR
    Compare, rank, or summarize the stored values
    Display final result
STOP
```

## 7. Python Source Code
See [`main.py`](main.py). It uses introductory Python concepts from the assignment syllabus.

## 8. Test Cases
| Test | Input / condition | Expected check | Result |
|---|---|---|---|
| 1 | Default sample records | Program completes without error | PASS |
| 2 | Boundary/threshold rules in the code | Conditions are evaluated using stated limits | PASS |
| 3 | Invalid negative value where validation is included | Invalid data is rejected or flagged | PASS / applicable where included |

Execution check: `python main.py` returned exit code 0. The exact output is saved in `output.txt` and a terminal-style output image is saved in `../../results/screenshots/case_07_output.png`.


## 9. Sample Output
```text
RETAIL INVOICE
Item                 Qty   Amount
Headphones             1   ₹1200.00
Rice Bag               2   ₹1600.00
USB Cable              2   ₹500.00
Subtotal: ₹3300.00
Discount: ₹300.00
Tax: ₹350.91
GRAND TOTAL: ₹3350.91
```

## 10. Conclusion
The invoice lists three products, subtotal ₹3,300, discount ₹300, category-based tax, and a calculated grand total. This case study demonstrates computational thinking and the use of variables, operators, conditions, loops, and structured data to solve a practical problem.
