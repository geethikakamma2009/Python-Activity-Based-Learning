# Case Study 2: Progressive Electricity Billing
def energy_charge(units):
    if units < 0:
        raise ValueError("Units cannot be negative")
    first = min(units, 100) * 2
    second = min(max(units - 100, 0), 100) * 3
    third = max(units - 200, 0) * 5
    return first + second + third

def calculate_bill(units):
    energy = energy_charge(units)
    subtotal = energy + 50
    surcharge = energy * 0.05
    subtotal += surcharge
    rebate = subtotal * 0.10 if units <= 100 else 0
    return round(subtotal - rebate, 2)

monthly_units = [("August", 90), ("September", 120), ("October", 260)]
bills = []
print("PROGRESSIVE ELECTRICITY BILLING")
for month, units in monthly_units:
    bill = calculate_bill(units)
    bills.append((month, units, bill))
    print(f"{month}: {units} units | Bill: ₹{bill:.2f}")
print("\nMONTH-TO-MONTH CHECK")
for index in range(1, len(bills)):
    previous = bills[index - 1][2]
    current = bills[index][2]
    increase = ((current - previous) / previous) * 100 if previous else 0
    status = "UNUSUAL INCREASE" if increase > 30 else "Within limit"
    print(f"{bills[index][0]} vs {bills[index-1][0]}: {increase:.1f}% increase - {status}")
