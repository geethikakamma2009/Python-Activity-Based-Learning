# Case Study 2: Progressive Electricity Billing

## 1. Problem Statement
Calculate household electricity bills using consumption slabs, a fixed charge, surcharge, and rebate; compare bills across months and flag an unusual increase.

## 2. Objectives
- Apply progressive consumption slabs correctly.
- Add fixed charges and surcharge, then apply an eligible rebate.
- Compare monthly bills and flag increases greater than 30%.

## 3. Assumptions
- Slab rates: first 100 units ₹2/unit, next 100 ₹3/unit, above 200 ₹5/unit.
- Fixed charge is ₹50 per month.
- Surcharge is 5% of energy charge; a 10% rebate applies to the final subtotal when consumption is at most 100 units.
- A month is flagged if its bill is more than 30% above the previous month.

## 4. Algorithm
1. Start the program.
2. Store the sample records and policy constants in variables, lists, or dictionaries.
3. Validate inputs where applicable.
4. Use arithmetic operators and conditional statements to calculate the required values.
5. Use loops to process all records and lists to store intermediate results.
6. Apply ranking, comparison, or summary logic as required.
7. Display the final results and stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read sample records and rules]
    B --> C[Validate inputs]
    C --> D[Calculate values using variables and operators]
    D --> E{Eligibility / threshold condition?}
    E -->|Yes| F[Record result / apply rule]
    E -->|No| G[Record alternative result]
    F --> H[Display summary and test results]
    G --> H
    H --> I([End])
```

## 6. Pseudocode
```text
START
    Set the sample data and policy constants
    FOR each record
        Validate values
        Calculate the required totals and conditions
        Display the record result
        Store eligible/summary values when required
    END FOR
    Compare, rank, or summarize the stored values
    Display final result
STOP
```

## 7. Python Source Code
See [`main.py`](main.py). It uses introductory Python concepts from the assignment syllabus.

## 8. Test Cases
| Test | Input / condition | Expected check | Result |
|---|---|---|---|
| 1 | Default sample records | Program completes without error | PASS |
| 2 | Boundary/threshold rules in the code | Conditions are evaluated using stated limits | PASS |
| 3 | Invalid negative value where validation is included | Invalid data is rejected or flagged | PASS / applicable where included |

Execution check: `python main.py` returned exit code 0. The exact output is saved in `output.txt` and a terminal-style output image is saved in `../../results/screenshots/case_02_output.png`.


## 9. Sample Output
```text
PROGRESSIVE ELECTRICITY BILLING
August: 90 units | Bill: ₹215.10
September: 120 units | Bill: ₹323.00
October: 260 units | Bill: ₹890.00

MONTH-TO-MONTH CHECK
September vs August: 50.2% increase - UNUSUAL INCREASE
October vs September: 175.5% increase - UNUSUAL INCREASE
```

## 10. Conclusion
August 90 units: ₹215.10; September 120 units: ₹323.00; October 260 units: ₹890.00. Increases over 30% are flagged. This case study demonstrates computational thinking and the use of variables, operators, conditions, loops, and structured data to solve a practical problem.
