# Case Study 6: Railway Fare and Reservation Calculator

## 1. Problem Statement
Calculate fares for passengers using distance slabs, travel class, age-based concession, reservation fee, and cancellation penalty.

## 2. Objectives
- Calculate distance-based base fare.
- Apply class multiplier and eligible age concession.
- Add reservation fee and calculate cancellation refund.

## 3. Assumptions
- Base rate is ₹1.20 per km for the first 100 km and ₹0.80 per km beyond 100 km.
- Class multipliers: Sleeper 1.0, AC 2.0.
- Children under 12 receive 50% concession; passengers aged 60 or more receive 25% concession. Only one concession applies, with the higher eligible concession selected.
- Reservation fee is ₹40 per passenger. Cancellation penalty is 20% of the fare before reservation fee; refund is not below zero.

## 4. Algorithm
1. Start the program.
2. Store the sample records and policy constants in variables, lists, or dictionaries.
3. Validate inputs where applicable.
4. Use arithmetic operators and conditional statements to calculate the required values.
5. Use loops to process all records and lists to store intermediate results.
6. Apply ranking, comparison, or summary logic as required.
7. Display the final results and stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read sample records and rules]
    B --> C[Validate inputs]
    C --> D[Calculate values using variables and operators]
    D --> E{Eligibility / threshold condition?}
    E -->|Yes| F[Record result / apply rule]
    E -->|No| G[Record alternative result]
    F --> H[Display summary and test results]
    G --> H
    H --> I([End])
```

## 6. Pseudocode
```text
START
    Set the sample data and policy constants
    FOR each record
        Validate values
        Calculate the required totals and conditions
        Display the record result
        Store eligible/summary values when required
    END FOR
    Compare, rank, or summarize the stored values
    Display final result
STOP
```

## 7. Python Source Code
See [`main.py`](main.py). It uses introductory Python concepts from the assignment syllabus.

## 8. Test Cases
| Test | Input / condition | Expected check | Result |
|---|---|---|---|
| 1 | Default sample records | Program completes without error | PASS |
| 2 | Boundary/threshold rules in the code | Conditions are evaluated using stated limits | PASS |
| 3 | Invalid negative value where validation is included | Invalid data is rejected or flagged | PASS / applicable where included |

Execution check: `python main.py` returned exit code 0. The exact output is saved in `output.txt` and a terminal-style output image is saved in `../../results/screenshots/case_06_output.png`.


## 9. Sample Output
```text
RAILWAY FARE AND RESERVATION
Kiran: concession=50%, payable=₹132.00
Lakshmi: original fare=₹400.00, cancellation penalty=₹72.00, refund=₹328.00
Manoj: concession=0%, payable=₹136.00
```

## 10. Conclusion
The program displays payable fares for Kiran and Manoj and the cancellation penalty/refund for Lakshmi. This case study demonstrates computational thinking and the use of variables, operators, conditions, loops, and structured data to solve a practical problem.
