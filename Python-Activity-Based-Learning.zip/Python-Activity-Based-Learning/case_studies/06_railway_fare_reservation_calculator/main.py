# Case Study 6: Railway Fare and Reservation Calculator
def base_fare(distance):
    if distance <= 0:
        raise ValueError("Distance must be positive")
    return min(distance, 100) * 1.20 + max(distance - 100, 0) * 0.80

passengers = [
    {"name": "Kiran", "age": 10, "distance": 180, "travel_class": "Sleeper", "cancel": False},
    {"name": "Lakshmi", "age": 65, "distance": 250, "travel_class": "AC", "cancel": True},
    {"name": "Manoj", "age": 30, "distance": 80, "travel_class": "Sleeper", "cancel": False},
]
class_multiplier = {"Sleeper": 1.0, "AC": 2.0}
print("RAILWAY FARE AND RESERVATION")
for passenger in passengers:
    if passenger["travel_class"] not in class_multiplier:
        print(f"{passenger['name']}: Invalid travel class")
        continue
    fare = base_fare(passenger["distance"]) * class_multiplier[passenger["travel_class"]]
    if passenger["age"] < 12:
        concession_rate = 0.50
    elif passenger["age"] >= 60:
        concession_rate = 0.25
    else:
        concession_rate = 0
    discounted = fare * (1 - concession_rate)
    total = discounted + 40
    if passenger["cancel"]:
        penalty = discounted * 0.20
        refund = max(total - penalty, 0)
        print(f"{passenger['name']}: original fare=₹{total:.2f}, cancellation penalty=₹{penalty:.2f}, refund=₹{refund:.2f}")
    else:
        print(f"{passenger['name']}: concession={concession_rate*100:.0f}%, payable=₹{total:.2f}")
