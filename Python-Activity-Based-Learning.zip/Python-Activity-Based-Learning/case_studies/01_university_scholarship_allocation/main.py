# Case Study 1: University Scholarship Allocation
applicants = [
    {"name": "Ananya", "marks": [88, 91, 84], "attendance": 92, "income": 180000},
    {"name": "Bharat", "marks": [82, 79, 85], "attendance": 88, "income": 220000},
    {"name": "Charan", "marks": [95, 93, 96], "attendance": 81, "income": 150000},
    {"name": "Divya", "marks": [86, 88, 90], "attendance": 90, "income": 240000},
    {"name": "Esha", "marks": [78, 83, 80], "attendance": 95, "income": 200000},
]
MIN_SUBJECT = 40
MIN_AGGREGATE = 80
MIN_ATTENDANCE = 85
MAX_INCOME = 250000
eligible = []
print("UNIVERSITY SCHOLARSHIP ALLOCATION")
for applicant in applicants:
    aggregate = sum(applicant["marks"]) / len(applicant["marks"])
    subject_ok = all(mark >= MIN_SUBJECT for mark in applicant["marks"])
    is_eligible = (aggregate >= MIN_AGGREGATE and subject_ok
                   and applicant["attendance"] >= MIN_ATTENDANCE
                   and applicant["income"] <= MAX_INCOME)
    print(f"{applicant['name']}: aggregate={aggregate:.2f}%, eligible={'Yes' if is_eligible else 'No'}")
    if is_eligible:
        eligible.append((applicant["name"], aggregate, applicant["attendance"]))
eligible.sort(key=lambda item: (-item[1], -item[2], item[0]))
print("\nRANKED ELIGIBLE APPLICANTS")
if eligible:
    for rank, (name, aggregate, attendance) in enumerate(eligible, start=1):
        print(f"{rank}. {name} | Aggregate: {aggregate:.2f}% | Attendance: {attendance}%")
else:
    print("No eligible applicants.")
