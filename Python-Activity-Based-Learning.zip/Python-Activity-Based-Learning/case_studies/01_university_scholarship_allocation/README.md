# Case Study 1: University Scholarship Allocation

## 1. Problem Statement
Evaluate applicants using aggregate marks, subject-wise minimum scores, attendance, and family-income criteria. Rank eligible students and resolve ties by higher aggregate, then higher attendance, then name.

## 2. Objectives
- Validate applicant data against stated eligibility rules.
- Identify eligible applicants using aggregate, subject minimum, attendance, and income.
- Rank eligible applicants deterministically using tie-breaking rules.

## 3. Assumptions
- Marks are percentages from 0 to 100.
- Each applicant must score at least 40 in every listed subject.
- Eligibility requires aggregate at least 80%, attendance at least 85%, and annual family income no more than ₹250,000.
- Sample records are illustrative, not official scholarship policy.

## 4. Algorithm
1. Start the program.
2. Store the sample records and policy constants in variables, lists, or dictionaries.
3. Validate inputs where applicable.
4. Use arithmetic operators and conditional statements to calculate the required values.
5. Use loops to process all records and lists to store intermediate results.
6. Apply ranking, comparison, or summary logic as required.
7. Display the final results and stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read sample records and rules]
    B --> C[Validate inputs]
    C --> D[Calculate values using variables and operators]
    D --> E{Eligibility / threshold condition?}
    E -->|Yes| F[Record result / apply rule]
    E -->|No| G[Record alternative result]
    F --> H[Display summary and test results]
    G --> H
    H --> I([End])
```

## 6. Pseudocode
```text
START
    Set the sample data and policy constants
    FOR each record
        Validate values
        Calculate the required totals and conditions
        Display the record result
        Store eligible/summary values when required
    END FOR
    Compare, rank, or summarize the stored values
    Display final result
STOP
```

## 7. Python Source Code
See [`main.py`](main.py). It uses introductory Python concepts from the assignment syllabus.

## 8. Test Cases
| Test | Input / condition | Expected check | Result |
|---|---|---|---|
| 1 | Default sample records | Program completes without error | PASS |
| 2 | Boundary/threshold rules in the code | Conditions are evaluated using stated limits | PASS |
| 3 | Invalid negative value where validation is included | Invalid data is rejected or flagged | PASS / applicable where included |

Execution check: `python main.py` returned exit code 0. The exact output is saved in `output.txt` and a terminal-style output image is saved in `../../results/screenshots/case_01_output.png`.


## 9. Sample Output
```text
UNIVERSITY SCHOLARSHIP ALLOCATION
Ananya: aggregate=87.67%, eligible=Yes
Bharat: aggregate=82.00%, eligible=Yes
Charan: aggregate=94.67%, eligible=No
Divya: aggregate=88.00%, eligible=Yes
Esha: aggregate=80.33%, eligible=Yes

RANKED ELIGIBLE APPLICANTS
1. Divya | Aggregate: 88.00% | Attendance: 90%
2. Ananya | Aggregate: 87.67% | Attendance: 92%
3. Bharat | Aggregate: 82.00% | Attendance: 88%
4. Esha | Aggregate: 80.33% | Attendance: 95%
```

## 10. Conclusion
Eligible applicants: Ananya (87.67%), Divya (88.00%), and Esha (80.33%). Ranking: Divya, Ananya, Esha. Bharat fails aggregate; Charan fails attendance. This case study demonstrates computational thinking and the use of variables, operators, conditions, loops, and structured data to solve a practical problem.
