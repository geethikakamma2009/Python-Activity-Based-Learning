# Case Study 3: Hospital Billing and Patient Classification

## 1. Problem Statement
Calculate consultation, diagnostic, and treatment charges; apply a concession under a stated rule, validate charges, and classify the payment status.

## 2. Objectives
- Calculate total hospital charges from component costs.
- Apply concession only when the patient qualifies.
- Reject negative charges and classify final bills.

## 3. Assumptions
- Senior citizens aged 60 or more receive a 10% concession on the bill before tax.
- GST is assumed to be 5% of the discounted amount for this classroom exercise.
- Payment classification: paid amount equal to final bill = Paid; positive but lower = Partially paid; zero = Pending.
- All sample charges are non-negative.

## 4. Algorithm
1. Start the program.
2. Store the sample records and policy constants in variables, lists, or dictionaries.
3. Validate inputs where applicable.
4. Use arithmetic operators and conditional statements to calculate the required values.
5. Use loops to process all records and lists to store intermediate results.
6. Apply ranking, comparison, or summary logic as required.
7. Display the final results and stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read sample records and rules]
    B --> C[Validate inputs]
    C --> D[Calculate values using variables and operators]
    D --> E{Eligibility / threshold condition?}
    E -->|Yes| F[Record result / apply rule]
    E -->|No| G[Record alternative result]
    F --> H[Display summary and test results]
    G --> H
    H --> I([End])
```

## 6. Pseudocode
```text
START
    Set the sample data and policy constants
    FOR each record
        Validate values
        Calculate the required totals and conditions
        Display the record result
        Store eligible/summary values when required
    END FOR
    Compare, rank, or summarize the stored values
    Display final result
STOP
```

## 7. Python Source Code
See [`main.py`](main.py). It uses introductory Python concepts from the assignment syllabus.

## 8. Test Cases
| Test | Input / condition | Expected check | Result |
|---|---|---|---|
| 1 | Default sample records | Program completes without error | PASS |
| 2 | Boundary/threshold rules in the code | Conditions are evaluated using stated limits | PASS |
| 3 | Invalid negative value where validation is included | Invalid data is rejected or flagged | PASS / applicable where included |

Execution check: `python main.py` returned exit code 0. The exact output is saved in `output.txt` and a terminal-style output image is saved in `../../results/screenshots/case_03_output.png`.


## 9. Sample Output
```text
HOSPITAL BILLING AND PATIENT CLASSIFICATION
Ravi: subtotal=₹4700.00, concession=₹470.00, tax=₹211.50, total=₹4441.50, balance=₹441.50, status=Partially paid
Meena: subtotal=₹2700.00, concession=₹0.00, tax=₹135.00, total=₹2835.00, balance=₹2835.00, status=Pending
Sana: subtotal=₹3600.00, concession=₹0.00, tax=₹180.00, total=₹3780.00, balance=₹1280.00, status=Partially paid
```

## 10. Conclusion
Ravi receives senior-citizen concession; Meena is Pending; Sana is Partially paid. Final amounts are computed from the displayed charges and rules. This case study demonstrates computational thinking and the use of variables, operators, conditions, loops, and structured data to solve a practical problem.
