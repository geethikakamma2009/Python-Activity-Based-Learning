# Case Study 3: Hospital Billing and Patient Classification
patients = [
    {"name": "Ravi", "age": 65, "consultation": 500, "diagnostics": 1200, "treatment": 3000, "paid": 4000},
    {"name": "Meena", "age": 35, "consultation": 400, "diagnostics": 800, "treatment": 1500, "paid": 0},
    {"name": "Sana", "age": 48, "consultation": 600, "diagnostics": 1000, "treatment": 2000, "paid": 2500},
]
print("HOSPITAL BILLING AND PATIENT CLASSIFICATION")
for patient in patients:
    charges = [patient["consultation"], patient["diagnostics"], patient["treatment"]]
    if any(charge < 0 for charge in charges) or patient["paid"] < 0:
        print(f"{patient['name']}: Invalid negative amount")
        continue
    subtotal = sum(charges)
    concession = subtotal * 0.10 if patient["age"] >= 60 else 0
    taxable = subtotal - concession
    tax = taxable * 0.05
    total = round(taxable + tax, 2)
    if patient["paid"] >= total:
        status = "Paid"
    elif patient["paid"] > 0:
        status = "Partially paid"
    else:
        status = "Pending"
    balance = max(total - patient["paid"], 0)
    print(f"{patient['name']}: subtotal=₹{subtotal:.2f}, concession=₹{concession:.2f}, "
          f"tax=₹{tax:.2f}, total=₹{total:.2f}, balance=₹{balance:.2f}, status={status}")
