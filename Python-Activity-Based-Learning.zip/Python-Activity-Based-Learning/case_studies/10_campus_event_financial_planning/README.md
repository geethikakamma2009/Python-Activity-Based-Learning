# Case Study 10: Campus Event Financial Planning

## 1. Problem Statement
Calculate event expenses, participant contributions, sponsorship shortfall, and the minimum number of registrations needed to break even.

## 2. Objectives
- Sum all event cost components.
- Calculate the remaining amount after sponsorship.
- Determine the minimum registration count for break-even.

## 3. Assumptions
- Venue ₹12,000; equipment ₹5,000; catering ₹250 per participant; transport ₹3,000; certificates ₹30 per participant.
- Sponsorship is ₹10,000 and registration fee is ₹400 per participant.
- Break-even participants = ceiling((fixed costs − sponsorship)/(registration fee − per-person variable cost)).
- A participant contributes ₹400; catering and certificate costs vary by participant.

## 4. Algorithm
1. Start the program.
2. Store the sample records and policy constants in variables, lists, or dictionaries.
3. Validate inputs where applicable.
4. Use arithmetic operators and conditional statements to calculate the required values.
5. Use loops to process all records and lists to store intermediate results.
6. Apply ranking, comparison, or summary logic as required.
7. Display the final results and stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read sample records and rules]
    B --> C[Validate inputs]
    C --> D[Calculate values using variables and operators]
    D --> E{Eligibility / threshold condition?}
    E -->|Yes| F[Record result / apply rule]
    E -->|No| G[Record alternative result]
    F --> H[Display summary and test results]
    G --> H
    H --> I([End])
```

## 6. Pseudocode
```text
START
    Set the sample data and policy constants
    FOR each record
        Validate values
        Calculate the required totals and conditions
        Display the record result
        Store eligible/summary values when required
    END FOR
    Compare, rank, or summarize the stored values
    Display final result
STOP
```

## 7. Python Source Code
See [`main.py`](main.py). It uses introductory Python concepts from the assignment syllabus.

## 8. Test Cases
| Test | Input / condition | Expected check | Result |
|---|---|---|---|
| 1 | Default sample records | Program completes without error | PASS |
| 2 | Boundary/threshold rules in the code | Conditions are evaluated using stated limits | PASS |
| 3 | Invalid negative value where validation is included | Invalid data is rejected or flagged | PASS / applicable where included |

Execution check: `python main.py` returned exit code 0. The exact output is saved in `output.txt` and a terminal-style output image is saved in `../../results/screenshots/case_10_output.png`.


## 9. Sample Output
```text
CAMPUS EVENT FINANCIAL PLAN
Fixed costs: venue ₹12000, equipment ₹5000, transport ₹3000 = ₹20000
Variable cost per participant: ₹280
Expected participants: 80
Expected registration revenue: ₹32000.00
Sponsorship: ₹10000.00
Expected expenses: ₹42400.00
Expected revenue: ₹42000.00
Financial balance: Shortfall ₹400.00
Minimum registrations to break even: 84
```

## 10. Conclusion
For 80 participants: revenue ₹42,000, expenses ₹42,400, shortfall ₹400. Minimum registrations to cover fixed costs after sponsorship: 84. This case study demonstrates computational thinking and the use of variables, operators, conditions, loops, and structured data to solve a practical problem.
