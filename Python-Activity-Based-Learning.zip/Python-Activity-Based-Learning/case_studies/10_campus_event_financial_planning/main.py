# Case Study 10: Campus Event Financial Planning
venue = 12000
equipment = 5000
transport = 3000
sponsorship = 10000
catering_per_person = 250
certificate_per_person = 30
registration_fee = 400
expected_participants = 80
fixed_cost = venue + equipment + transport
variable_cost_per_person = catering_per_person + certificate_per_person
expected_revenue = sponsorship + registration_fee * expected_participants
expected_expenses = fixed_cost + variable_cost_per_person * expected_participants
balance = expected_revenue - expected_expenses
contribution_per_person = registration_fee - variable_cost_per_person
if contribution_per_person > 0:
    amount_to_cover = max(fixed_cost - sponsorship, 0)
    minimum_participants = (amount_to_cover + contribution_per_person - 1) // contribution_per_person
else:
    minimum_participants = None
print("CAMPUS EVENT FINANCIAL PLAN")
print(f"Fixed costs: venue ₹{venue}, equipment ₹{equipment}, transport ₹{transport} = ₹{fixed_cost}")
print(f"Variable cost per participant: ₹{variable_cost_per_person}")
print(f"Expected participants: {expected_participants}")
print(f"Expected registration revenue: ₹{registration_fee * expected_participants:.2f}")
print(f"Sponsorship: ₹{sponsorship:.2f}")
print(f"Expected expenses: ₹{expected_expenses:.2f}")
print(f"Expected revenue: ₹{expected_revenue:.2f}")
print(f"Financial balance: {'Surplus' if balance >= 0 else 'Shortfall'} ₹{abs(balance):.2f}")
if minimum_participants is None:
    print("Break-even is not possible at this registration fee.")
else:
    print(f"Minimum registrations to break even: {minimum_participants}")
