# Case Study 8: Manufacturing Cost and Profitability Analysis
quantity = 100
material_cost_per_unit = 120
wastage_rate = 0.05
labour_per_unit = 25
machine_cost = 1500
selling_price_per_unit = 200
target_profit = 4000
material_cost = quantity * material_cost_per_unit
wastage_cost = material_cost * wastage_rate
labour_cost = quantity * labour_per_unit
total_cost = material_cost + wastage_cost + labour_cost + machine_cost
revenue = quantity * selling_price_per_unit
profit = revenue - total_cost
profit_margin = (profit / revenue) * 100 if revenue else 0
print("MANUFACTURING COST AND PROFITABILITY")
print(f"Quantity: {quantity} units")
print(f"Material cost: ₹{material_cost:.2f}")
print(f"Wastage cost: ₹{wastage_cost:.2f}")
print(f"Labour cost: ₹{labour_cost:.2f}")
print(f"Machine cost: ₹{machine_cost:.2f}")
print(f"Total cost: ₹{total_cost:.2f}")
print(f"Revenue: ₹{revenue:.2f}")
print(f"Profit: ₹{profit:.2f} | Profit margin: {profit_margin:.2f}%")
print(f"Target profit: ₹{target_profit:.2f} | Target achieved: {'Yes' if profit >= target_profit else 'No'}")
