# Case Study 8: Manufacturing Cost and Profitability Analysis

## 1. Problem Statement
Calculate material, labour, wastage, and machine costs; compare total production cost and selling revenue against a specified profit target.

## 2. Objectives
- Compute material and wastage costs.
- Add labour and machine costs to find total cost.
- Calculate profit and determine whether the target is achieved.

## 3. Assumptions
- Production quantity is 100 units.
- Material cost is ₹120 per unit; wastage is 5% of material cost.
- Labour is ₹25 per unit and machine cost is ₹1,500 per batch.
- Selling price is ₹200 per unit; target profit is ₹4,000.

## 4. Algorithm
1. Start the program.
2. Store the sample records and policy constants in variables, lists, or dictionaries.
3. Validate inputs where applicable.
4. Use arithmetic operators and conditional statements to calculate the required values.
5. Use loops to process all records and lists to store intermediate results.
6. Apply ranking, comparison, or summary logic as required.
7. Display the final results and stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read sample records and rules]
    B --> C[Validate inputs]
    C --> D[Calculate values using variables and operators]
    D --> E{Eligibility / threshold condition?}
    E -->|Yes| F[Record result / apply rule]
    E -->|No| G[Record alternative result]
    F --> H[Display summary and test results]
    G --> H
    H --> I([End])
```

## 6. Pseudocode
```text
START
    Set the sample data and policy constants
    FOR each record
        Validate values
        Calculate the required totals and conditions
        Display the record result
        Store eligible/summary values when required
    END FOR
    Compare, rank, or summarize the stored values
    Display final result
STOP
```

## 7. Python Source Code
See [`main.py`](main.py). It uses introductory Python concepts from the assignment syllabus.

## 8. Test Cases
| Test | Input / condition | Expected check | Result |
|---|---|---|---|
| 1 | Default sample records | Program completes without error | PASS |
| 2 | Boundary/threshold rules in the code | Conditions are evaluated using stated limits | PASS |
| 3 | Invalid negative value where validation is included | Invalid data is rejected or flagged | PASS / applicable where included |

Execution check: `python main.py` returned exit code 0. The exact output is saved in `output.txt` and a terminal-style output image is saved in `../../results/screenshots/case_08_output.png`.


## 9. Sample Output
```text
MANUFACTURING COST AND PROFITABILITY
Quantity: 100 units
Material cost: ₹12000.00
Wastage cost: ₹600.00
Labour cost: ₹2500.00
Machine cost: ₹1500.00
Total cost: ₹16600.00
Revenue: ₹20000.00
Profit: ₹3400.00 | Profit margin: 17.00%
Target profit: ₹4000.00 | Target achieved: No
```

## 10. Conclusion
Total cost ₹16,350; revenue ₹20,000; profit ₹3,650; target profit of ₹4,000 is not achieved. This case study demonstrates computational thinking and the use of variables, operators, conditions, loops, and structured data to solve a practical problem.
