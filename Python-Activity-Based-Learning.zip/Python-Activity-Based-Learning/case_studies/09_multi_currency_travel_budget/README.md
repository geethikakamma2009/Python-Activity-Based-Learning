# Case Study 9: Multi-Currency Travel Budget Analysis

## 1. Problem Statement
Convert travel expenses using supplied exchange rates, add conversion fees, compare total spending against a budget, and identify the largest expense category.

## 2. Objectives
- Convert expenses from foreign currencies to INR.
- Calculate conversion fees and total expenditure.
- Compare total with budget and find the largest category.

## 3. Assumptions
- Rates are sample rates supplied for this assignment: USD ₹83.00, EUR ₹90.00, GBP ₹105.00.
- A 2% conversion fee is applied to converted amounts.
- Budget is ₹50,000.
- Rates are illustrative and must not be treated as current exchange rates.

## 4. Algorithm
1. Start the program.
2. Store the sample records and policy constants in variables, lists, or dictionaries.
3. Validate inputs where applicable.
4. Use arithmetic operators and conditional statements to calculate the required values.
5. Use loops to process all records and lists to store intermediate results.
6. Apply ranking, comparison, or summary logic as required.
7. Display the final results and stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read sample records and rules]
    B --> C[Validate inputs]
    C --> D[Calculate values using variables and operators]
    D --> E{Eligibility / threshold condition?}
    E -->|Yes| F[Record result / apply rule]
    E -->|No| G[Record alternative result]
    F --> H[Display summary and test results]
    G --> H
    H --> I([End])
```

## 6. Pseudocode
```text
START
    Set the sample data and policy constants
    FOR each record
        Validate values
        Calculate the required totals and conditions
        Display the record result
        Store eligible/summary values when required
    END FOR
    Compare, rank, or summarize the stored values
    Display final result
STOP
```

## 7. Python Source Code
See [`main.py`](main.py). It uses introductory Python concepts from the assignment syllabus.

## 8. Test Cases
| Test | Input / condition | Expected check | Result |
|---|---|---|---|
| 1 | Default sample records | Program completes without error | PASS |
| 2 | Boundary/threshold rules in the code | Conditions are evaluated using stated limits | PASS |
| 3 | Invalid negative value where validation is included | Invalid data is rejected or flagged | PASS / applicable where included |

Execution check: `python main.py` returned exit code 0. The exact output is saved in `output.txt` and a terminal-style output image is saved in `../../results/screenshots/case_09_output.png`.


## 9. Sample Output
```text
MULTI-CURRENCY TRAVEL BUDGET
Hotel: 250 USD = ₹20750.00 + fee ₹415.00 = ₹21165.00
Food: 120 EUR = ₹10800.00 + fee ₹216.00 = ₹11016.00
Transport: 80 GBP = ₹8400.00 + fee ₹168.00 = ₹8568.00
Shopping: 100 USD = ₹8300.00 + fee ₹166.00 = ₹8466.00

Total spend: ₹49215.00
Budget: ₹50000.00 | Status: Within budget
Largest expense category: Hotel (₹21165.00)
```

## 10. Conclusion
All foreign expenses are converted using the supplied rates and 2% fee; the report shows total spend, budget status, and largest category. This case study demonstrates computational thinking and the use of variables, operators, conditions, loops, and structured data to solve a practical problem.
