# Case Study 9: Multi-Currency Travel Budget Analysis
exchange_rates = {"USD": 83.00, "EUR": 90.00, "GBP": 105.00}
expenses = [
    {"category": "Hotel", "amount": 250, "currency": "USD"},
    {"category": "Food", "amount": 120, "currency": "EUR"},
    {"category": "Transport", "amount": 80, "currency": "GBP"},
    {"category": "Shopping", "amount": 100, "currency": "USD"},
]
fee_rate = 0.02
budget = 50000
converted_expenses = []
print("MULTI-CURRENCY TRAVEL BUDGET")
for expense in expenses:
    currency = expense["currency"]
    if currency not in exchange_rates or expense["amount"] < 0:
        print(f"Invalid expense record: {expense}")
        continue
    converted = expense["amount"] * exchange_rates[currency]
    fee = converted * fee_rate
    total = converted + fee
    converted_expenses.append((expense["category"], total))
    print(f"{expense['category']}: {expense['amount']} {currency} = ₹{converted:.2f} + fee ₹{fee:.2f} = ₹{total:.2f}")
total_spend = sum(amount for _, amount in converted_expenses)
print(f"\nTotal spend: ₹{total_spend:.2f}")
print(f"Budget: ₹{budget:.2f} | Status: {'Within budget' if total_spend <= budget else 'Over budget'}")
if converted_expenses:
    category, amount = max(converted_expenses, key=lambda item: item[1])
    print(f"Largest expense category: {category} (₹{amount:.2f})")
