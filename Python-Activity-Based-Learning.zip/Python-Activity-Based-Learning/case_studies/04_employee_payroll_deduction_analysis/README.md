# Case Study 4: Employee Payroll and Deduction Analysis

## 1. Problem Statement
Calculate employee gross salary from basic pay, allowances, overtime, and incentives; apply progressive deductions and print a salary statement.

## 2. Objectives
- Compute gross salary using multiple components.
- Apply deductions in defined salary bands.
- Display net salary in a readable statement.

## 3. Assumptions
- HRA is 20% and other allowance is 10% of basic pay.
- Overtime is paid at ₹200 per hour; incentive is supplied per employee.
- Deduction: 5% of gross up to ₹25,000; 10% of the amount above ₹25,000 up to ₹50,000; 15% of the amount above ₹50,000.
- These are hypothetical classroom rules, not statutory payroll advice.

## 4. Algorithm
1. Start the program.
2. Store the sample records and policy constants in variables, lists, or dictionaries.
3. Validate inputs where applicable.
4. Use arithmetic operators and conditional statements to calculate the required values.
5. Use loops to process all records and lists to store intermediate results.
6. Apply ranking, comparison, or summary logic as required.
7. Display the final results and stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read sample records and rules]
    B --> C[Validate inputs]
    C --> D[Calculate values using variables and operators]
    D --> E{Eligibility / threshold condition?}
    E -->|Yes| F[Record result / apply rule]
    E -->|No| G[Record alternative result]
    F --> H[Display summary and test results]
    G --> H
    H --> I([End])
```

## 6. Pseudocode
```text
START
    Set the sample data and policy constants
    FOR each record
        Validate values
        Calculate the required totals and conditions
        Display the record result
        Store eligible/summary values when required
    END FOR
    Compare, rank, or summarize the stored values
    Display final result
STOP
```

## 7. Python Source Code
See [`main.py`](main.py). It uses introductory Python concepts from the assignment syllabus.

## 8. Test Cases
| Test | Input / condition | Expected check | Result |
|---|---|---|---|
| 1 | Default sample records | Program completes without error | PASS |
| 2 | Boundary/threshold rules in the code | Conditions are evaluated using stated limits | PASS |
| 3 | Invalid negative value where validation is included | Invalid data is rejected or flagged | PASS / applicable where included |

Execution check: `python main.py` returned exit code 0. The exact output is saved in `output.txt` and a terminal-style output image is saved in `../../results/screenshots/case_04_output.png`.


## 9. Sample Output
```text
EMPLOYEE PAYROLL STATEMENT

Employee: Arjun
Basic: ₹22000.00 | HRA: ₹4400.00 | Other allowance: ₹2200.00
Overtime: ₹1000.00 | Incentive: ₹1500.00
Gross: ₹31100.00 | Deduction: ₹1860.00 | Net salary: ₹29240.00

Employee: Priya
Basic: ₹40000.00 | HRA: ₹8000.00 | Other allowance: ₹4000.00
Overtime: ₹1600.00 | Incentive: ₹3000.00
Gross: ₹56600.00 | Deduction: ₹4740.00 | Net salary: ₹51860.00
```

## 10. Conclusion
The program prints a separate gross salary, progressive deduction, and net salary statement for Arjun and Priya. This case study demonstrates computational thinking and the use of variables, operators, conditions, loops, and structured data to solve a practical problem.
