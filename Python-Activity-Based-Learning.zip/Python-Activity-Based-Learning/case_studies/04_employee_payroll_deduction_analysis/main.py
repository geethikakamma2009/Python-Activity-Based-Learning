# Case Study 4: Employee Payroll and Deduction Analysis
def progressive_deduction(gross):
    first = min(gross, 25000) * 0.05
    second = min(max(gross - 25000, 0), 25000) * 0.10
    third = max(gross - 50000, 0) * 0.15
    return first + second + third

employees = [
    {"name": "Arjun", "basic": 22000, "overtime_hours": 5, "incentive": 1500},
    {"name": "Priya", "basic": 40000, "overtime_hours": 8, "incentive": 3000},
]
print("EMPLOYEE PAYROLL STATEMENT")
for employee in employees:
    basic = employee["basic"]
    hra = basic * 0.20
    allowance = basic * 0.10
    overtime = employee["overtime_hours"] * 200
    gross = basic + hra + allowance + overtime + employee["incentive"]
    deduction = progressive_deduction(gross)
    net = gross - deduction
    print(f"\nEmployee: {employee['name']}")
    print(f"Basic: ₹{basic:.2f} | HRA: ₹{hra:.2f} | Other allowance: ₹{allowance:.2f}")
    print(f"Overtime: ₹{overtime:.2f} | Incentive: ₹{employee['incentive']:.2f}")
    print(f"Gross: ₹{gross:.2f} | Deduction: ₹{deduction:.2f} | Net salary: ₹{net:.2f}")
