# Case Study 5: Telecommunications Cost Optimization
usage_gb = 70
required_validity = 28
budget = 700
plans = [
    {"name": "Basic", "price": 299, "data_gb": 40, "validity": 28, "extra_rate": 20},
    {"name": "Smart", "price": 499, "data_gb": 75, "validity": 28, "extra_rate": 15},
    {"name": "Max", "price": 699, "data_gb": 100, "validity": 56, "extra_rate": 10},
    {"name": "Mini", "price": 199, "data_gb": 30, "validity": 14, "extra_rate": 25},
]
eligible = []
print("MOBILE PLAN COST COMPARISON")
for plan in plans:
    excess = max(usage_gb - plan["data_gb"], 0)
    cost = plan["price"] + excess * plan["extra_rate"]
    meets_needs = plan["validity"] >= required_validity and cost <= budget
    print(f"{plan['name']}: data={plan['data_gb']} GB, validity={plan['validity']} days, "
          f"estimated cost=₹{cost:.2f}, eligible={'Yes' if meets_needs else 'No'}")
    if meets_needs:
        eligible.append((cost, plan["name"]))
print("\nRECOMMENDATION")
if eligible:
    cost, name = min(eligible)
    print(f"Most economical eligible plan: {name} at ₹{cost:.2f}")
else:
    print("No plan satisfies the requirements and budget.")
