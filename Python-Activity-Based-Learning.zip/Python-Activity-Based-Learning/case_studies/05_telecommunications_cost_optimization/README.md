# Case Study 5: Multi-Plan Telecommunications Cost Optimization

## 1. Problem Statement
Compare mobile plans using usage, validity, and budget constraints; calculate excess charges and choose the cheapest plan that meets the usage and validity requirements.

## 2. Objectives
- Estimate each plan’s total cost for the supplied usage.
- Exclude plans that do not meet data, validity, or budget needs.
- Select the lowest-cost eligible plan.

## 3. Assumptions
- Usage is 2.5 GB/day for 28 days, so required data is 70 GB.
- Plans include a data allowance and validity in days.
- Excess data is charged at the stated per-GB rate; budget is ₹700.
- All plan data and costs are illustrative.

## 4. Algorithm
1. Start the program.
2. Store the sample records and policy constants in variables, lists, or dictionaries.
3. Validate inputs where applicable.
4. Use arithmetic operators and conditional statements to calculate the required values.
5. Use loops to process all records and lists to store intermediate results.
6. Apply ranking, comparison, or summary logic as required.
7. Display the final results and stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read sample records and rules]
    B --> C[Validate inputs]
    C --> D[Calculate values using variables and operators]
    D --> E{Eligibility / threshold condition?}
    E -->|Yes| F[Record result / apply rule]
    E -->|No| G[Record alternative result]
    F --> H[Display summary and test results]
    G --> H
    H --> I([End])
```

## 6. Pseudocode
```text
START
    Set the sample data and policy constants
    FOR each record
        Validate values
        Calculate the required totals and conditions
        Display the record result
        Store eligible/summary values when required
    END FOR
    Compare, rank, or summarize the stored values
    Display final result
STOP
```

## 7. Python Source Code
See [`main.py`](main.py). It uses introductory Python concepts from the assignment syllabus.

## 8. Test Cases
| Test | Input / condition | Expected check | Result |
|---|---|---|---|
| 1 | Default sample records | Program completes without error | PASS |
| 2 | Boundary/threshold rules in the code | Conditions are evaluated using stated limits | PASS |
| 3 | Invalid negative value where validation is included | Invalid data is rejected or flagged | PASS / applicable where included |

Execution check: `python main.py` returned exit code 0. The exact output is saved in `output.txt` and a terminal-style output image is saved in `../../results/screenshots/case_05_output.png`.


## 9. Sample Output
```text
MOBILE PLAN COST COMPARISON
Basic: data=40 GB, validity=28 days, estimated cost=₹899.00, eligible=No
Smart: data=75 GB, validity=28 days, estimated cost=₹499.00, eligible=Yes
Max: data=100 GB, validity=56 days, estimated cost=₹699.00, eligible=Yes
Mini: data=30 GB, validity=14 days, estimated cost=₹1199.00, eligible=No

RECOMMENDATION
Most economical eligible plan: Smart at ₹499.00
```

## 10. Conclusion
Smart and Max meet the stated usage/validity/budget conditions; Smart is the lowest-cost eligible plan at ₹499. This case study demonstrates computational thinking and the use of variables, operators, conditions, loops, and structured data to solve a practical problem.
