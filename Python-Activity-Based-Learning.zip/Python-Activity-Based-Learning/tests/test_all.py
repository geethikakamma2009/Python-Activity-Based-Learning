import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class CaseStudySmokeTests(unittest.TestCase):
    def test_all_ten_programs_run_successfully(self):
        folders = sorted((ROOT / "case_studies").iterdir())
        self.assertEqual(len(folders), 10)
        for folder in folders:
            with self.subTest(case=folder.name):
                result = subprocess.run([sys.executable, str(folder / "main.py")], capture_output=True, text=True)
                self.assertEqual(result.returncode, 0, msg=result.stderr)
                self.assertTrue(result.stdout.strip(), msg="No output produced")

if __name__ == "__main__":
    unittest.main()
