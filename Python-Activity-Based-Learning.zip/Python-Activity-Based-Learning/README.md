# Python Activity-Based Learning (ABL) Assignment

**Course:** Python Programming  
**Assignment:** Activity-Based Learning (ABL)  
**Selected case studies:** 1–10 from the supplied faculty case-study list  
**Date prepared:** 23 October 2026

## Project contents
- `case_studies/`: ten independent Python programs, documentation, and captured text output.
- `results/screenshots/`: terminal-style output screenshots for each program.
- `tests/test_all.py`: automated smoke tests that execute all ten programs and check successful completion.
- `Consolidated_Report.pdf`: consolidated report containing problem statement, objectives, assumptions, algorithm, flowchart, pseudocode, code reference, test cases, sample output, and conclusion for every case study.
- `results/test_results.txt`: result of the automated execution checks.

## Selected case studies
1. University Scholarship Allocation
2. Progressive Electricity Billing
3. Hospital Billing and Patient Classification
4. Employee Payroll and Deduction Analysis
5. Multi-Plan Telecommunications Cost Optimization
6. Railway Fare and Reservation Calculator
7. Retail Billing with Multiple Discount Rules
8. Manufacturing Cost and Profitability Analysis
9. Multi-Currency Travel Budget Analysis
10. Campus Event Financial Planning

## Requirements
- Python 3.9 or later
- No third-party Python packages are required to run the programs.

## Run one program
Open the project folder in VS Code, open a case-study folder, and run:

```bash
python main.py
```

For example:

```bash
cd case_studies/01_university_scholarship_allocation
python main.py
```

## Run all automated checks
From the project root:

```bash
python -m unittest discover -s tests -v
```

## GitHub submission reminder
Create a GitHub repository named exactly `Python-Activity-Based-Learning`, upload the contents of this folder, and submit the repository URL to your faculty member/lab mentor. This ZIP does not create or publish a GitHub repository automatically.

## Academic integrity and policy note
The policy values and sample records are stated in each case study as assumptions for demonstrating the syllabus. They are not official scholarship, billing, payroll, railway, telecom, currency, or tax policies. Review the programs, run them yourself, and be ready to explain the logic to your faculty member.
